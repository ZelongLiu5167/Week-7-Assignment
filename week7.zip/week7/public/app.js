window.addEventListener('load',()=> {
    document.getElementById('button-lunch').addEventListener('click', ()=> {
        let nalunch = document.getElementById('answer-lunch').value;
        console.log(nalunch);

        //creating the object 
        let obj = {"name" : nalunch};

        //stringify the object
        let jsonData = JSON.stringify(obj);

        fetch('/nalunch', {
            method: 'POST',
            headers: {
                "Content-type": "application/json"
            },
            body: jsonData
        })
        .then(response => response.json())
        .then(data => {console.log(data)});

        //1. make a fetch request of type POST so that we can send the (nalunch) info to the server
    })

    document.getElementById('record-lunch').addEventListener('click', ()=> {
        //get info on ALL the coffees we've had so far
        fetch('/getlunch')
        .then(resp=> resp.json())
        .then(data => {
            document.getElementById('list-lunch').innerHTML = '';
            console.log(data.data);
            for(let i=0;i<data.data.length;i++) {
                let string = data.data[i].date + " : " + data.data[i].coffee;
                let elt = document.createElement('p');
                elt.innerHTML = string;
                document.getElementById('list-lunch').appendChild(elt);
            }
        })
    })
})